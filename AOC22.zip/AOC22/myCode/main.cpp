#include <iostream>
#include <vector>
#include <string>

#include "CDay1.h"
#include "CDay2.h"
#include "CDay3.h"
#include "CDay4.h"
#include "CDay5.h"

using namespace std;



int main()
{
    //CDay1 day1;
    //day1.calculateHighestCalories();

//	CDay2 day2;
//	day2.calculateScore(CDay2::part1);
//	day2.calculateScore(CDay2::part2);

//	CDay3 day3;
//	day3.task1();
//	day3.task2();


//	CDay4 day4;
//	day4.tasks();

	CDay5 day5_task1;
	day5_task1.task1();
	CDay5 day5_task2;
	day5_task2.task2();

}
